export const ADMOB_IDS = {
  appId: "ca-app-pub-9958539812897899~2242325345",
  banner: "ca-app-pub-9958539812897899/1507828173",
  interstitial: "ca-app-pub-9958539812897899/4293773610",
  rewarded: "ca-app-pub-9958539812897899/8400364577",
  projectId: "ef33cb0d-98cc-46a7-9585-c90bca183642"
};
