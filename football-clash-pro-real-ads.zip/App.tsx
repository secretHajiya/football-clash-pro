import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  View, Text, Pressable, StyleSheet, Dimensions, PanResponder,
  StatusBar, TextInput, Alert
} from "react-native";
import mobileAds, {
  BannerAd, BannerAdSize, InterstitialAd, RewardedAd,
  AdEventType, RewardedAdEventType
} from "react-native-google-mobile-ads";
import { ADMOB_IDS } from "./admobConfig";

const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get("window");
const TEAMS = ["Barcelona", "Real Madrid", "Man City", "Nigeria", "Arsenal", "PSG"];
const BLUE = "#1478e8";
const RED = "#e43b42";

type Player = { id: number; x: number; y: number; team: "blue" | "red"; keeper?: boolean };
type Screen = "teams" | "match" | "online";

const makeTeam = (): Player[] => {
  const players: Player[] = [];
  // 10 outfield players in a compact 4-3-3 formation plus goalkeeper.
  const blueCoords = [[7,50],[22,20],[22,40],[22,60],[22,80],[42,25],[42,50],[42,75],[62,30],[62,50],[62,70]];
  const redCoords = [[93,50],[78,20],[78,40],[78,60],[78,80],[58,25],[58,50],[58,75],[38,30],[38,50],[38,70]];
  blueCoords.forEach((p, i) => players.push({ id: i, x: p[0], y: p[1], team: "blue", keeper: i === 0 }));
  redCoords.forEach((p, i) => players.push({ id: i + 11, x: p[0], y: p[1], team: "red", keeper: i === 0 }));
  return players;
};

const interstitial = InterstitialAd.createForAdRequest(ADMOB_IDS.interstitial);
const rewarded = RewardedAd.createForAdRequest(ADMOB_IDS.rewarded);

export default function App() {
  const [screen, setScreen] = useState<Screen>("teams");
  const [team, setTeam] = useState("Barcelona");
  const [opponent, setOpponent] = useState("Real Madrid");
  const [players, setPlayers] = useState<Player[]>(makeTeam());
  const [ball, setBall] = useState({ x: 50, y: 50 });
  const [score, setScore] = useState([0, 0]);
  const [seconds, setSeconds] = useState(120);
  const [stamina, setStamina] = useState(100);
  const [coins, setCoins] = useState(0);
  const [card, setCard] = useState<"Yellow Card" | "Red Card" | null>(null);
  const [roomCode, setRoomCode] = useState("");
  const [active, setActive] = useState(false);
  const [adReady, setAdReady] = useState({ interstitial: false, rewarded: false });
  const [joystick, setJoystick] = useState({ x: 0, y: 0 });
  const playerRef = useRef(players);
  const ballRef = useRef(ball);
  const joystickRef = useRef({ x: 0, y: 0 });
  playerRef.current = players;
  ballRef.current = ball;
  joystickRef.current = joystick;

  useEffect(() => {
    mobileAds().initialize().catch(() => {});
    const iLoaded = interstitial.addAdEventListener(AdEventType.LOADED, () => setAdReady(s => ({ ...s, interstitial: true })));
    const rLoaded = rewarded.addAdEventListener(RewardedAdEventType.LOADED, () => setAdReady(s => ({ ...s, rewarded: true })));
    const rEarned = rewarded.addAdEventListener(RewardedAdEventType.EARNED_REWARD, () => setCoins(c => c + 50));
    interstitial.load();
    rewarded.load();
    return () => { iLoaded(); rLoaded(); rEarned(); };
  }, []);

  useEffect(() => {
    if (screen !== "match" || !active) return;
    const timer = setInterval(() => {
      setSeconds(s => {
        if (s <= 1) {
          setActive(false);
          if (adReady.interstitial) interstitial.show().catch(() => {});
          return 0;
        }
        return s - 1;
      });
      setStamina(s => Math.max(0, s - (Math.abs(joystickRef.current.x) + Math.abs(joystickRef.current.y) > 0.2 ? 1.4 : 0.25)));
      setPlayers(old => old.map(p => {
        if (p.team !== "red" || p.keeper) return p;
        const dx = ballRef.current.x - p.x;
        const dy = ballRef.current.y - p.y;
        return { ...p, x: clamp(p.x + Math.sign(dx) * 0.45, 3, 97), y: clamp(p.y + Math.sign(dy) * 0.35, 4, 96) };
      }));
    }, 1000);
    return () => clearInterval(timer);
  }, [screen, active, adReady.interstitial]);

  useEffect(() => {
    if (screen !== "match" || !active) return;
    const tick = setInterval(() => {
      const j = joystickRef.current;
      if (Math.abs(j.x) + Math.abs(j.y) < 0.05) return;
      setPlayers(old => {
        const next = old.map(p => p.id === 6
          ? { ...p, x: clamp(p.x + j.x * (stamina > 0 ? 1.25 : 0.55), 3, 97), y: clamp(p.y + j.y * (stamina > 0 ? 1.5 : 0.65), 4, 96) }
          : p);
        const controlled = next.find(p => p.id === 6)!;
        setBall(b => {
          if (distance(controlled.x, controlled.y, b.x, b.y) < 7) return { x: controlled.x + 2, y: controlled.y };
          return b;
        });
        return next;
      });
    }, 90);
    return () => clearInterval(tick);
  }, [screen, active, stamina]);

  const resetMatch = () => {
    setPlayers(makeTeam()); setBall({ x: 50, y: 50 }); setScore([0, 0]);
    setSeconds(120); setStamina(100); setCard(null); setActive(true); setScreen("match");
  };
  const moveBall = (action: "PASS" | "SHOOT") => {
    const p = players.find(x => x.id === 6)!;
    const targetX = action === "SHOOT" ? 98 : clamp(p.x + 16, 0, 100);
    const targetY = action === "SHOOT" ? 50 : clamp(p.y + (Math.random() * 24 - 12), 5, 95);
    setBall({ x: targetX, y: targetY });
    if (action === "SHOOT" && p.x > 67 && Math.abs(p.y - 50) < 27) {
      setScore(s => [s[0] + 1, s[1]]);
      setBall({ x: 50, y: 50 });
      Alert.alert("GOAL!", `${team} scored!`);
    }
    setStamina(s => Math.max(0, s - (action === "SHOOT" ? 8 : 3)));
  };
  const doTackle = () => {
    setStamina(s => Math.max(0, s - 7));
    if (Math.random() < 0.22) setCard("Yellow Card");
    setBall(b => ({ x: clamp(b.x - 8, 3, 97), y: clamp(b.y + (Math.random() * 16 - 8), 4, 96) }));
  };
  const doSprint = () => {
    if (stamina < 5) return;
    setStamina(s => Math.max(0, s - 5));
    setPlayers(old => old.map(p => p.id === 6 ? { ...p, x: clamp(p.x + 4, 3, 97) } : p));
  };
  const openReward = () => {
    if (adReady.rewarded) rewarded.show().then(() => rewarded.load()).catch(() => {});
    else Alert.alert("Reward not ready", "Please try again in a moment.");
  };
  const timeLabel = `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`;

  if (screen === "teams") {
    return <View style={styles.page}>
      <StatusBar hidden />
      <Text style={styles.logo}>FOOTBALL CLASH <Text style={{ color: "#ffc72c" }}>PRO</Text></Text>
      <Text style={styles.tagline}>11 VS 11 • HARD FOOTBALL</Text>
      <Text style={styles.sectionTitle}>SELECT YOUR TEAM</Text>
      <View style={styles.teamGrid}>
        {TEAMS.map((t, i) => <Pressable key={t} onPress={() => setTeam(t)} style={[styles.teamCard, team === t && styles.selectedCard]}>
          <Text style={styles.teamBadge}>{["🔵","⚪","🩵","🇳🇬","🔴","🔵"][i]}</Text>
          <Text style={styles.teamName}>{t}</Text>
        </Pressable>)}
      </View>
      <View style={styles.bottomActions}>
        <Pressable style={styles.primaryButton} onPress={resetMatch}><Text style={styles.buttonText}>OFFLINE HARD AI</Text></Pressable>
        <Pressable style={styles.secondaryButton} onPress={() => setScreen("online")}><Text style={styles.buttonText}>ONLINE VS FRIEND</Text></Pressable>
      </View>
      <Text style={styles.note}>Choose a team, then enter the pitch.</Text>
    </View>;
  }

  if (screen === "online") {
    return <View style={styles.page}>
      <StatusBar hidden />
      <Text style={styles.logo}>ONLINE VS FRIEND</Text>
      <Text style={styles.tagline}>ROOM CODE LOBBY</Text>
      <Text style={styles.sectionTitle}>Create or join a room</Text>
      <TextInput value={roomCode} onChangeText={setRoomCode} placeholder="Enter friend's room code" placeholderTextColor="#8c9bb1" autoCapitalize="characters" style={styles.roomInput} />
      <View style={styles.bottomActions}>
        <Pressable style={styles.primaryButton} onPress={() => { const code = Math.random().toString(36).slice(2, 8).toUpperCase(); setRoomCode(code); Alert.alert("Room created", `Share this code with your friend: ${code}`, [{ text: "OK", onPress: resetMatch }]); }}><Text style={styles.buttonText}>CREATE ROOM</Text></Pressable>
        <Pressable style={styles.secondaryButton} onPress={() => { if (roomCode.trim().length < 4) { Alert.alert("Room code needed", "Enter a valid room code."); return; } Alert.alert("Room code accepted", "This demo opens the match locally. Live multiplayer requires a game server.", [{ text: "Continue", onPress: resetMatch }]); }}><Text style={styles.buttonText}>JOIN ROOM</Text></Pressable>
      </View>
      <Pressable onPress={() => setScreen("teams")}><Text style={styles.backText}>← BACK TO TEAM SELECT</Text></Pressable>
    </View>;
  }

  return <View style={styles.matchPage}>
    <StatusBar hidden />
    <View style={styles.hud}>
      <Text style={styles.hudTeam}>{team}</Text>
      <Text style={styles.score}>{score[0]} - {score[1]}</Text>
      <Text style={styles.hudTeam}>{opponent}</Text>
      <Text style={styles.timer}>{timeLabel}</Text>
      <Pressable onPress={() => { setActive(false); setScreen("teams"); }}><Text style={styles.exit}>EXIT</Text></Pressable>
    </View>
    <View style={styles.pitch}>
      <View style={styles.midLine} /><View style={styles.centerCircle} />
      <View style={styles.leftBox} /><View style={styles.rightBox} />
      <View style={styles.leftGoal} /><View style={styles.rightGoal} />
      {players.map(p => <View key={p.id} style={[styles.player, {
        left: `${p.x}%`, top: `${p.y}%`, backgroundColor: p.team === "blue" ? BLUE : RED,
        borderWidth: p.id === 6 ? 3 : 1, borderColor: p.id === 6 ? "#fff" : "#101b28",
      }]}><Text style={styles.playerNumber}>{p.id % 11 + 1}</Text></View>)}
      <View style={[styles.ball, { left: `${ball.x}%`, top: `${ball.y}%` }]} />
    </View>
    <View style={styles.controls}>
      <View style={styles.joystickArea} {...PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onMoveShouldSetPanResponder: () => true,
        onPanResponderMove: (_, g) => setJoystick({ x: clamp(g.dx / 45, -1, 1), y: clamp(g.dy / 45, -1, 1) }),
        onPanResponderRelease: () => setJoystick({ x: 0, y: 0 }),
      }).panHandlers}>
        <View style={styles.joystickRing}><View style={[styles.joystickKnob, { transform: [{ translateX: joystick.x * 22 }, { translateY: joystick.y * 22 }] }]} /></View>
        <Text style={styles.controlCaption}>JOYSTICK</Text>
      </View>
      <View style={styles.actionButtons}>
        <Pressable style={[styles.actionButton, { backgroundColor: "#e3a51b" }]} onPress={doSprint}><Text style={styles.actionText}>SPRINT</Text></Pressable>
        <Pressable style={[styles.actionButton, { backgroundColor: "#1686e8" }]} onPress={() => moveBall("PASS")}><Text style={styles.actionText}>PASS</Text></Pressable>
        <Pressable style={[styles.actionButton, { backgroundColor: "#24a05a" }]} onPress={() => moveBall("SHOOT")}><Text style={styles.actionText}>SHOOT</Text></Pressable>
        <Pressable style={[styles.actionButton, { backgroundColor: "#d94a43" }]} onPress={doTackle}><Text style={styles.actionText}>TACKLE</Text></Pressable>
      </View>
      <View style={styles.statusPanel}>
        <Text style={styles.statusLabel}>STAMINA {Math.round(stamina)}%</Text>
        <View style={styles.staminaTrack}><View style={[styles.staminaFill, { width: `${stamina}%`, backgroundColor: stamina < 25 ? "#e43b42" : "#55d77a" }]} /></View>
        {card ? <Pressable onPress={() => setCard(null)}><Text style={styles.cardText}>{card} ✕</Text></Pressable> : <Text style={styles.smallStatus}>HARD AI ACTIVE</Text>}
        <Pressable style={styles.rewardButton} onPress={openReward}><Text style={styles.rewardText}>WATCH AD · +50 COINS</Text></Pressable>
        <Text style={styles.coins}>🪙 {coins}</Text>
      </View>
    </View>
    <View style={styles.adContainer}><BannerAd unitId={ADMOB_IDS.banner} size={BannerAdSize.BANNER} requestOptions={{ requestNonPersonalizedAdsOnly: true }} /></View>
  </View>;
}

function clamp(n: number, min: number, max: number) { return Math.max(min, Math.min(max, n)); }
function distance(x1: number, y1: number, x2: number, y2: number) { return Math.sqrt((x1-x2)**2 + (y1-y2)**2); }

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: "#071322", alignItems: "center", justifyContent: "center", paddingHorizontal: 24 },
  logo: { color: "#f4f7fb", fontSize: 30, fontWeight: "900", letterSpacing: 2, textAlign: "center" },
  tagline: { color: "#9db2ca", fontSize: 12, fontWeight: "800", letterSpacing: 3, marginTop: 6, marginBottom: 22 },
  sectionTitle: { color: "#e9f2ff", fontWeight: "800", fontSize: 15, marginBottom: 14, letterSpacing: 1 },
  teamGrid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "center", maxWidth: 620, gap: 10 },
  teamCard: { width: 145, height: 72, borderRadius: 12, backgroundColor: "#14253a", borderWidth: 2, borderColor: "#253b55", alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 8 },
  selectedCard: { borderColor: "#ffc72c", backgroundColor: "#23344a" },
  teamBadge: { fontSize: 20 }, teamName: { color: "white", fontSize: 12, fontWeight: "800" },
  bottomActions: { flexDirection: "row", gap: 12, marginTop: 22 },
  primaryButton: { backgroundColor: "#1679e8", paddingVertical: 14, paddingHorizontal: 22, borderRadius: 9 },
  secondaryButton: { backgroundColor: "#243951", paddingVertical: 14, paddingHorizontal: 22, borderRadius: 9, borderWidth: 1, borderColor: "#48617d" },
  buttonText: { color: "#fff", fontWeight: "900", fontSize: 12, letterSpacing: 0.7 },
  note: { color: "#748ba5", fontSize: 11, marginTop: 18 },
  roomInput: { width: 290, borderRadius: 10, borderWidth: 1, borderColor: "#3b526d", backgroundColor: "#13263a", padding: 14, color: "white", marginVertical: 12, textAlign: "center" },
  backText: { color: "#9eb1c7", fontSize: 12, fontWeight: "800", marginTop: 25 },
  matchPage: { flex: 1, backgroundColor: "#071322", paddingTop: 4 },
  hud: { height: 35, flexDirection: "row", alignItems: "center", justifyContent: "space-around", paddingHorizontal: 8 },
  hudTeam: { color: "#dce8f7", fontSize: 11, fontWeight: "800", width: "25%", textAlign: "center" },
  score: { color: "#fff", fontSize: 18, fontWeight: "900" },
  timer: { color: "#ffc72c", fontSize: 14, fontWeight: "900" },
  exit: { color: "#ff8585", fontWeight: "900", fontSize: 11 },
  pitch: { flex: 1, marginHorizontal: 9, marginVertical: 3, backgroundColor: "#19783c", borderWidth: 2, borderColor: "#e2f5e5", overflow: "hidden" },
  midLine: { position: "absolute", left: "50%", top: 0, bottom: 0, width: 2, backgroundColor: "#d2f1d8" },
  centerCircle: { position: "absolute", width: 70, height: 70, borderRadius: 35, borderWidth: 2, borderColor: "#d2f1d8", left: "50%", top: "50%", marginLeft: -35, marginTop: -35 },
  leftBox: { position: "absolute", width: "13%", height: "52%", left: 0, top: "24%", borderWidth: 2, borderLeftWidth: 0, borderColor: "#d2f1d8" },
  rightBox: { position: "absolute", width: "13%", height: "52%", right: 0, top: "24%", borderWidth: 2, borderRightWidth: 0, borderColor: "#d2f1d8" },
  leftGoal: { position: "absolute", width: 7, height: "18%", left: 0, top: "41%", borderWidth: 1, borderColor: "white" },
  rightGoal: { position: "absolute", width: 7, height: "18%", right: 0, top: "41%", borderWidth: 1, borderColor: "white" },
  player: { position: "absolute", width: 23, height: 23, marginLeft: -11, marginTop: -11, borderRadius: 12, alignItems: "center", justifyContent: "center", elevation: 3 },
  playerNumber: { color: "white", fontSize: 9, fontWeight: "900" },
  ball: { position: "absolute", width: 11, height: 11, marginLeft: -5, marginTop: -5, borderRadius: 6, backgroundColor: "#fff", borderWidth: 2, borderColor: "#202020", elevation: 4 },
  controls: { height: 112, flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 14 },
  joystickArea: { width: 105, alignItems: "center", justifyContent: "center" },
  joystickRing: { width: 72, height: 72, borderRadius: 40, borderWidth: 2, borderColor: "#8aa3be", backgroundColor: "#172a3e", alignItems: "center", justifyContent: "center" },
  joystickKnob: { width: 31, height: 31, borderRadius: 17, backgroundColor: "#d7e5f4", borderWidth: 2, borderColor: "#fff" },
  controlCaption: { color: "#8fa7c0", fontSize: 9, fontWeight: "800", marginTop: 3 },
  actionButtons: { flex: 1, flexDirection: "row", justifyContent: "center", flexWrap: "wrap", gap: 7, paddingHorizontal: 7 },
  actionButton: { minWidth: 68, paddingHorizontal: 9, paddingVertical: 12, borderRadius: 9, alignItems: "center", justifyContent: "center" },
  actionText: { color: "white", fontWeight: "900", fontSize: 10 },
  statusPanel: { width: 130, alignItems: "stretch", gap: 4 },
  statusLabel: { color: "#dbe8f6", fontSize: 9, fontWeight: "900" },
  staminaTrack: { height: 8, backgroundColor: "#26384b", borderRadius: 5, overflow: "hidden" },
  staminaFill: { height: 8, borderRadius: 5 },
  smallStatus: { color: "#7fa0bd", fontSize: 8, fontWeight: "800" },
  cardText: { color: "#ffd34f", fontSize: 9, fontWeight: "900" },
  rewardButton: { backgroundColor: "#7958d6", paddingVertical: 6, paddingHorizontal: 5, borderRadius: 5, alignItems: "center" },
  rewardText: { color: "#fff", fontSize: 8, fontWeight: "900" },
  coins: { color: "#ffc72c", fontSize: 10, fontWeight: "900" },
  adContainer: { height: 52, alignItems: "center", justifyContent: "center", backgroundColor: "#071322" }
});
